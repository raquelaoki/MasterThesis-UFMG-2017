rm(list = ls( all = T))
bd = read.table("v031_escala_phi_jogos.csv",header=T, sep=";")
bd = subset(bd, equipes>=7)


bd$sport = as.character(bd$sport)
bd$sport[bd$sport=="basketball"]="Basketball"
bd$sport[bd$sport=="handball"]="Handball"
bd$sport[bd$sport=="soccer"]="Soccer"
bd$sport[bd$sport=="voleyball"]="Volleyball"

windows(15,10)
#Comparando diferentes esportes 
boxplot(bd$valor.phi~bd$sport,col = "seagreen3",main="",xlab="Sport",
	ylab=expression(paste("Scale ",phi,sep=" ")))
abline(h = seq(-2,2,by=0.5),lty=2,lwd=1,col="lightgrey")
boxplot(bd$valor.phi~bd$sport,col = "seagreen3",axes=F,add=T)
savePlot(filename="escala_phi_esportes", type="png", device=dev.cur())

#Comparando quantidade de equipes
boxplot(bd$valor.phi~bd$equipes,col = "cadetblue3",ylim=c(-1,1),
	xlab="Teams Number",main="")
abline(h = seq(-1,1,by=0.5),lty=2,lwd=1,col="lightgrey")
boxplot(bd$valor.phi~bd$equipes,col = "cadetblue3",ylim=c(-1,1),axes=F,add=T)
savePlot(filename=paste("escala_phi_quant_equipes_",option,sep=""), type="png", device=dev.cur())

#Comparando Sexo 
boxplot(bd$valor.phi~bd$gender,col = "cadetblue3",ylim=c(-1,1),xlab="Gender",
	main = "")
abline(h = seq(-1,1,by=0.5),lty=2,lwd=1,col="lightgrey")
boxplot(bd$valor.phi~bd$gender,col = "cadetblue3",ylim=c(-1,1),axes=F,add=T)
savePlot(filename=paste("escala_phi_sexo_",option,sep=""), type="png", device=dev.cur())

#Comparando sport e quantidade de equipes
esporte = as.character(unique(bd$sport))
bd$sport = as.character(bd$sport)
par(mfrow=c(2,2))
for(i in 1:length(esporte)) {
	bd.aux = subset(bd, sport==esporte[i])
	boxplot(bd.aux$valor.phi~bd.aux$equipes,col = "cadetblue3",ylim=c(-1,1),
		xlab=paste("Quantidade Equipes ",option,sep=""),main=esporte[i])
	abline(h = seq(-1,1,by=0.5),lty=2,lwd=1,col="lightgrey")
	boxplot(bd.aux$valor.phi~bd.aux$equipes,col = "cadetblue3",ylim=c(-1,1),axes=F,add=T)
}
savePlot(filename=paste("escala_phi_esportes_quant1_",option,sep=""), type="png", device=dev.cur())

#Comparando sport e quantidade de equipes
esporte = as.character(unique(bd$sport))
bd$sport = as.character(bd$sport)
par(mfrow=c(2,2))
for(i in 1:length(esporte)) {
	bd.aux = subset(bd, sport==esporte[i])
	boxplot(bd.aux$valor.phi~bd.aux$equipes,col = "seagreen3",
		xlab="League Size",main=esporte[i])
}
savePlot(filename=paste("escala_phi_esportes_quant2_",option,sep=""), type="png", device=dev.cur())


#Comparando sport e quantidade de equipes
esporte = as.character(unique(bd$sport))
bd$sport = as.character(bd$sport)
par(mfrow=c(2,2))
for(i in 1:length(esporte)) {
	bd.aux = subset(bd, sport==esporte[i])
	hist(bd.aux$equipes,col = "cadetblue3",xlab=paste("Quantidade Equipes ",option,sep=""),
		main=esporte[i])
}
savePlot(filename=paste("hist_esportes_quant_",option,sep=""), type="png", device=dev.cur())


par(mfrow=c(1,1))
#dos que s�o diferentes 
bd2 = subset(bd, pch!="Equal")
bd2$perc.retiradaos = bd2$retirados*100/bd2$equipes
#Comparando diferentes esportes 
boxplot(bd2$perc.retiradaos~bd2$sport,col = "seagreen3",ylim=c(0,100),
	ylab="% Teams Removed",main="")
abline(h = seq(0,100,by=10),lty=2,lwd=1,col="lightgrey")
boxplot(bd2$perc.retiradaos~bd2$sport,col = "seagreen3",ylim=c(0,100),axes=F,add=T)
savePlot(filename="escala_phi_quant_retirados",type="png", device=dev.cur())




#Fazendo tabela 
require(xtable)
tab1 = table(bd$sport,bd$pch)
sport = row.names(tab1);row.names(tab1)=NULL
tab1 = data.frame(cbind(sport, tab1))
tab1$Different = as.numeric(as.character(tab1$Different))
tab1$Equal = as.numeric(as.character(tab1$Equal))
tab1$Total = tab1$Different+tab1$Equal
total = data.frame(sport="Total", Different=sum(tab1$Different),
		Equal=sum(tab1$Equal),Total = sum(tab1$Total))
tab1 = rbind(tab1, total)
tab1$Dif.per = paste(round(tab1$Different*100/tab1$Total ,2),"\\%",sep="")
tab1$Eq.per = paste(round(tab1$Equal*100/tab1$Total,2),"\\%",sep="")

tab1 = tab1[,c(1,2,5,3,6,4)]

titulo = "\\multirow{2}{*}{Sport}&\\multicolumn{2}{c|}{Different}
	&\\multicolumn{2}{c|}{Equal}& \\multirow{2}{*}{Total}\\\\ \\cline{2-5}
	& Freq. & \\%& Freq. & \\% & \\\\"	

print(xtable(tab1,digits=0,caption="Result Escala $\\Phi$}\\label{tab1", 
	align="ll|cc|cc|c"), caption.placement='top',table.placement="H", 
	include.rownames = F, include.colnames=F, add.to.row = 
	list(pos = as.list(c(0)) ,  command=c(titulo)),
      sanitize.text.function = function(x){x})
 


k = 882





